package com.example.assignment01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String[] items = {"Mushroom($5)", "Sun Dried Tomato($5)", "Chicken($7)", "Green Pepper($5)", "Pineapple($5)", "Avacado($5)", "Tuna($5)", "Broccoli($5)"};
    AutoCompleteTextView autoCompleteTxt;
    ArrayAdapter<String> adapterItems;
    Pizza pizza;
    TextView total;
    double total_price;
    EditText txtName, txtAddress, txtPhoneNum, txtEadd, txtIns;
    TextView display;
    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        autoCompleteTxt = findViewById(R.id.auto_complete_txt);
        adapterItems = new ArrayAdapter<String>(this, R.layout.dropdown_item,items);
        autoCompleteTxt.setAdapter(adapterItems);

        txtName = findViewById(R.id.name);
        txtAddress = findViewById(R.id.address);
        txtPhoneNum = findViewById(R.id.phone);
        txtEadd = findViewById(R.id.eaddress);
        display = findViewById(R.id.info1);
        txtIns = findViewById(R.id.instruction);
        button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(txtName.getText().toString().isEmpty() || txtAddress.getText().toString().isEmpty() || txtPhoneNum.getText().toString().isEmpty() || txtEadd.getText().toString().isEmpty() || txtIns.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Empty Fields", Toast.LENGTH_SHORT).show();

                }else {
                    String name = txtName.getText().toString();
                    String address = txtAddress.getText().toString();
                    String phone = txtPhoneNum.getText().toString();
                    String email = txtEadd.getText().toString();
                    String instruction = txtIns.getText().toString();
                    display.setText(name + " " + address + " " + phone + " " + email + " " + instruction);
                }
            }
        });


        pizza = new Pizza();
        total = findViewById(R.id.total);

    }

    public void radioClicked(View view){
        //Is button now checked
        boolean checked = ((RadioButton) view).isChecked();
        //Check which radio button was clicked
        switch (view.getId()){
            case R.id.textInputLayout2:
                if (checked)
                    pizza.setPizza_set_price(5);
                break;
            case R.id.six:
                if (checked)
                    pizza.setPizza_set_price(5.50);
                break;
            case R.id.eight:
                if (checked)
                    pizza.setPizza_set_price(7.99);
                break;
            case R.id.ten:
                if (checked)
                    pizza.setPizza_set_price(9.50);
                break;
            case R.id.twelve:
                if (checked)
                    pizza.setPizza_set_price(11.38);
                break;

        }
        total.setText("Total Price:" + "$" +pizza.getPizza_set_price());
    }

    public void onCheckboxClicked(View view){
        //Is the view now checked?
        boolean checked = ((CheckBox) view).isChecked();
        //Check which value checkbox was clicked

        switch (view.getId()){
            case R.id.cheese:
                if (checked)
                    pizza.setExtra_cheese(5);
                else
                    pizza.setExtra_cheese(0);
                break;
            case R.id.delivery:
                if (checked)
                    pizza.setDelivery(5);
                else
                    pizza.setDelivery(0);
                break;


        }
        total.setText("Total Price:" +  "$" +calculate_total());
    }
    private double calculate_total() {
        total_price = pizza.getPizza_set_price() + pizza.getExtra_cheese() + pizza.getDelivery();
        return total_price;
    }
}