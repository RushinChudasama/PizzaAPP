package com.example.assignment01;



public class Pizza {
    double toppings = 0;
    double six_slice = 0;
    double eight_slice = 0 ;
    double ten_slice = 0;
    double twelve_slice = 0;
    double extra_cheese = 0;
    double delivery = 0;
    double pizza_set_price = 0;

    public Pizza(){
    }
    public double getToppings(){
        return toppings;
    }
    public void setToppings(double toppings) {
        this.toppings = toppings;
    }

    public double getSix_slice(){
        return six_slice;
    }
    public void setSix_slice(double eight_slice) {
        this.six_slice = six_slice;
    }

    public double getEight_slice(){
        return eight_slice;
    }
    public void setEight_slice(double eight_slice) {
        this.eight_slice = eight_slice;
    }

    public double getTen_slice(){
        return ten_slice;
    }
    public void setTen_slice(double ten_slice) {
        this.ten_slice = ten_slice;
    }

    public double getTwelve_slice(){
        return twelve_slice;
    }
    public void setTwelve_slice(double twelve_slice) {
        this.twelve_slice = twelve_slice;
    }

    public double getExtra_cheese(){
        return extra_cheese;
    }
    public void setExtra_cheese(double extra_cheese) {
        this.extra_cheese = extra_cheese;
    }

    public double getDelivery() {
        return delivery;
    }
    public void setDelivery(double delivery) {
        this.delivery = delivery;
    }

    public double getPizza_set_price() {
        return pizza_set_price;
    }
    public void setPizza_set_price(double pizza_set_price) {
        this.pizza_set_price = pizza_set_price;
    }
}
